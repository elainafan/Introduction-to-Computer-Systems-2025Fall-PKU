/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_173()
{
    return 2428995912U;
}

unsigned getval_135()
{
    return 2428995656U;
}

unsigned getval_121()
{
    return 2445773128U;
}

unsigned addval_382(unsigned x)
{
    return x + 2438465688U;
}

void setval_278(unsigned *p)
{
    *p = 2425393496U;
}

unsigned getval_200()
{
    return 3284633928U;
}

unsigned addval_392(unsigned x)
{
    return x + 3281016885U;
}

unsigned getval_258()
{
    return 3281016957U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_312(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_484(unsigned x)
{
    return x + 3525886345U;
}

unsigned getval_390()
{
    return 3374369417U;
}

unsigned addval_175(unsigned x)
{
    return x + 3375942281U;
}

unsigned addval_474(unsigned x)
{
    return x + 2430601544U;
}

void setval_160(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_427()
{
    return 3252717896U;
}

void setval_116(unsigned *p)
{
    *p = 3284834621U;
}

unsigned addval_432(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_108(unsigned x)
{
    return x + 3268053434U;
}

void setval_331(unsigned *p)
{
    *p = 3374891401U;
}

unsigned addval_255(unsigned x)
{
    return x + 3682124169U;
}

unsigned getval_298()
{
    return 3284830987U;
}

unsigned getval_165()
{
    return 3677407881U;
}

void setval_311(unsigned *p)
{
    *p = 3769190630U;
}

unsigned addval_229(unsigned x)
{
    return x + 3675835017U;
}

unsigned getval_193()
{
    return 3525367435U;
}

unsigned getval_387()
{
    return 3281046157U;
}

void setval_296(unsigned *p)
{
    *p = 3524837769U;
}

unsigned getval_279()
{
    return 3225998985U;
}

unsigned getval_249()
{
    return 3224950441U;
}

unsigned addval_367(unsigned x)
{
    return x + 3375945353U;
}

unsigned addval_377(unsigned x)
{
    return x + 3676362377U;
}

unsigned addval_262(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_450()
{
    return 3375939977U;
}

unsigned addval_281(unsigned x)
{
    return x + 2425476745U;
}

unsigned getval_148()
{
    return 3372799497U;
}

unsigned getval_329()
{
    return 3284241904U;
}

unsigned addval_117(unsigned x)
{
    return x + 3380920713U;
}

unsigned addval_330(unsigned x)
{
    return x + 2495711489U;
}

unsigned getval_444()
{
    return 3766568968U;
}

unsigned addval_360(unsigned x)
{
    return x + 2425411201U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
