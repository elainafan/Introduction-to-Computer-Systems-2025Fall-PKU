# y86-dbg: Debugger for y86 implemented in DAP

This is a debug (simulation) server for the Y86 assembly.