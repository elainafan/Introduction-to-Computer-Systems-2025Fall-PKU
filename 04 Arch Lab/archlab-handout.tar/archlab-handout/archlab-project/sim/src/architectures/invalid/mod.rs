//! Examples of invalid architectures. These architectures will fail on
//! computational graph construction.

mod circular_dep;
mod unused_unit_in;
