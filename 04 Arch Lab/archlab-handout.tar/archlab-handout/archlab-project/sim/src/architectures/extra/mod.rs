//! This module contains extra pipeline architectures defined by users.

// do not modify the following line, as it automatically includes all extra
// pipeline modules in current directory.
sim_macro::extra_pipelines!();
