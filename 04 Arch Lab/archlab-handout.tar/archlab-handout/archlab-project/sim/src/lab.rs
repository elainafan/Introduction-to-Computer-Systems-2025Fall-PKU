//! Utilities for lab.

pub const BOOL_PLACEHOLDER: bool = false;
pub const U8_PLACEHOLDER: u8 = 0;
pub const U64_PLACEHOLDER: u64 = 0;
